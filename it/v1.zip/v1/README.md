Design link: https://xd.adobe.com/view/4d200461-eea4-42f8-bee3-9705bd81bbe2-1873/specs/
